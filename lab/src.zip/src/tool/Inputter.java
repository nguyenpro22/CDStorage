package tool;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class Inputter {

    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final int CURRENT_YEAR = getYearFromDate(getToday());
    
    static Scanner sc = new Scanner(System.in);

    //method ép người dùng nhập số nguyên
    public static int getAnInteger(String inputMsg, String errorMsg) {
        System.out.print(inputMsg);
        int number;
        while (true) {
            try {
                number = Integer.parseInt(sc.nextLine());
                return number;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }
        }
    }

    //method ép người dùng nhập số nguyên trong khoảng nào đó
    public static int getAnInteger(String inputMsg, String errorMsg,
            int lowerBound, int upperBound) {
        if (lowerBound > upperBound) {
            int tmp = lowerBound;
            lowerBound = upperBound;
            upperBound = tmp;
        }
        System.out.print(inputMsg);
        int number;
        while (true) {
            try {
                number = Integer.parseInt(sc.nextLine());
                if (number > upperBound || number < lowerBound) {
                    throw new Exception();
                }
                return number;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }
        }
    }

    //method ép người dùng nhập số thực
    public static double getAnDouble(String inputMsg, String errorMsg) {
        System.out.print(inputMsg);
        Double number;
        while (true) {
            try {
                number = Double.parseDouble(sc.nextLine());
                return number;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }
        }
    }

    //method ép người dùng nhập số nguyên trong khoảng nào đó
    public static double getAnDouble(String inputMsg, String errorMsg,
            double lowerBound, double upperBound) {
        if (lowerBound > upperBound) {
            double tmp = lowerBound;
            lowerBound = upperBound;
            upperBound = tmp;
        }
        System.out.print(inputMsg);
        Double number;
        while (true) {
            try {
                number = Double.parseDouble(sc.nextLine());
                if (number > upperBound || number < lowerBound) {
                    throw new Exception();
                }
                return number;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }
        }
    }

    //method ép nhập String không bỏ trống
    public static String getString(String inputMsg, String errorMsg) {
        System.out.print(inputMsg);
        while (true) {
            try {
                String str = sc.nextLine();
                if (str.isEmpty() || str.isBlank()) {
                    throw new Exception();
                }
                return str;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }
               
        }

    }
    

    //method ép nhập String không bỏ trống và theo format
    public static String getString(String inputMsg, String errorMsg, String regex) {
        System.out.print(inputMsg);
        while (true) {
            try {
                String str = sc.nextLine();
                if (str.isEmpty() || !str.matches(regex)) {
                    throw new Exception();
                }
                return str;
            } catch (Exception e) {
                System.out.print(errorMsg);
            }

        }

    }

    public static Date inputDate(String inputMsg, String errorMsg) {
        Date date;
        System.out.print(inputMsg + "(" + DATE_FORMAT + "): ");
        do {
            try {
                SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT);
                df.setLenient(false);
                date = df.parse(sc.nextLine());
                return date;
            } catch (ParseException e) {
                System.out.print(errorMsg);
            }
        } while (true);
    }
    public static Date getToday(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
        LocalDateTime now = LocalDateTime.now();
        return parseDate(dtf.format(now));
    }
    public static Date parseDate(String dateStr){
        SimpleDateFormat dF = (SimpleDateFormat)SimpleDateFormat.getInstance();
        dF.applyPattern(DATE_FORMAT);
        try{
            long t = dF.parse(dateStr).getTime();
            return new Date(t);
        }catch(ParseException e){
            System.out.println(e);
        }
        return null;
    }
    public static Date validDate(String message){
        String input;
        Date inputDate;
        do{
            System.out.print(message + ": ");
            sc = new Scanner(System.in);
            input = sc.nextLine();
            inputDate = parseDate(input);
            if(inputDate == null) System.out.println("Wrong Date Format! Try again");
            if(!validYear(inputDate) || inputDate.after(getToday())) System.out.println(
                    "Date must not be after today, " + getToday()+ " and must be within 100 years!");
        }while(inputDate == null || !validYear(inputDate));
        return inputDate;
    }
    
    public static boolean validYear(Date date){
        return (CURRENT_YEAR - getYearFromDate(date)) < 120 && getYearFromDate(date) <= CURRENT_YEAR;
    }
    
    public static int getYearFromDate(Date date){
        return Integer.parseInt(dateToStr(date).substring(6));
    }
    
    public static String dateToStr(Date date){
        SimpleDateFormat dF = new SimpleDateFormat(DATE_FORMAT);
        return dF.format(date);
    }
    
    public static boolean inputBoolean(String msgInput, String msgError){
        System.out.print(msgInput);
        while(true){
            try{
                boolean a = Boolean.parseBoolean(sc.nextLine());
                return a;
            }catch(Exception e){
                System.out.print(msgError);
            }
        }
    }
}
