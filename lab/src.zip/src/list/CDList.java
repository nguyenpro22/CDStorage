package list;

import data.CD;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.stream.Collectors;
import tool.Inputter;

public class CDList extends ArrayList<CD> {

    Scanner sc = new Scanner(System.in);

    public CDList() {
        readFile();
    }

    public ArrayList<CD> getFanssionList() {
        return this;
    }

    public void addCD() {
        CD cd = new CD();
        cd.inputInfor();
        for (CD item : this) {
            if (item.getIdCD().equals(cd.getIdCD())) {
                System.out.println("The ID is Existed!");
                updateID(cd);
            }
        }
        this.add(cd);

    }

    public void searchByTitle(String title) {
        List list = filterTitle(title);
        if (list == null) {
            System.out.println("not found or nothing.");
            return;
        }
        Collections.sort(list, (CD c1, CD c2) -> c1.getTitleCD().compareTo(c2.getTitleCD()));
        for (Object obj : list) {
            CD cd = (CD) obj;
            cd.showInfor();
        }

    }

    @Override
    public boolean add(CD cd) {
        int idx = indexOf(cd);
        if (idx >= 0) {
            remove(idx);
        }
        return super.add(cd);
    }

    public CD updateCD(String id) {
        CD cd = searchByID(id);
        if (cd == null) {
            return cd;
        }
        updateName(cd);
        updateType(cd);
        updateTitle(cd);
        updatePrice(cd);
        updateYear(cd);
        return cd;
    }

    private void updateYear(CD cd) {
        System.out.print("Input the update Year Publishing CD: ");
        while (true) {
            try {
                String input = sc.nextLine();
                if (input.isBlank()) {
                    System.out.println("Year not change.");
                    return;
                }
                cd.setPublicYear(Integer.parseInt(input));
                return;
            } catch (Exception e) {
                System.out.print("Please Input a true year: ");
            }
        }
    }

    private void updatePrice(CD cd) {
        System.out.print("Input the update Price CD: ");
        while (true) {
            try {
                String input = sc.nextLine();
                if (input.isBlank()) {
                    System.out.println("Price not change.");
                    return;
                }
                cd.setPriceCD(Integer.parseInt(input));
                return;
            } catch (Exception e) {
                System.out.print("Please Input a true price: ");
            }
        }
    }

    private void updateType(CD cd) {
        String input = "";
        System.out.print("Input the update Type CD: ");
        while (!input.matches(CD.getTYPE_PATTERN())) {
            input = sc.nextLine();
            if (input.isBlank()) {
                System.out.println("Type not change.");
                return;
            }
            if (cd.getTypeCD().equals(input)) {
                System.out.println("Type not change.");
                return;
            }
            if(input.matches(CD.getTYPE_PATTERN())) break;
            System.out.print("Input the update Type CD with format("+CD.getTYPE_FORMAT()+"): ");
        }
        cd.setTypeCD(input);
    }

    private void updateName(CD cd) {
        String input = "";
        System.out.print("Input the update Name CD: ");
        while (!input.matches(CD.getNAME_PATTERN())) {
            input = sc.nextLine();
            if (input.isBlank()) {
                System.out.println("Name not change.");
                return;
            }
            if (cd.getNameCD().equals(input)) {
                System.out.println("Name not change.");
                return;
            }
            if(input.matches(CD.getNAME_PATTERN())) break;
            System.out.print("Input the update Name CD with format(" + CD.getNAME_FORMAT() + "): ");
        }
        cd.setNameCD(input);
    }

    public CD searchByID(String id) {
        for (CD item : this) {
            if (item.getIdCD().equals(id)) {
                return item;
            }
        }
        return null;
    }

    private void updateID(CD cd) {
        while (true) {
            String input = Inputter.getString("Input the update ID: ",
                    "Please Input in Right Format:(" + CD.getID_FORMAT() + ")",
                    CD.getID_PATTERN());
            boolean flag = false;
            for (CD item : this) {
                if (item.getIdCD().equals(input)) {
                    System.out.println("the CD ID has exited.");
                    flag = true;
                }
            }
            if (!flag) {
                cd.setIdCD(input);
                return;
            }

        }
    }

    private void updateTitle(CD cd) {
        System.out.print("Input the update Title CD: ");
            String input = sc.nextLine();
            if (input.isBlank()) {
                System.out.println("title not change.");
                return;
            }
            if (cd.getTitleCD().equals(input)) {
                System.out.println("title not change.");
                return;
            }
            cd.setTitleCD(input);
    }

    public void deleteCD(CD cd) {
        this.remove(this.indexOf(cd));
    }

    private int indexOf(CD cd) {
        int idx = 0;
        for (CD item : this) {
            if (item.getIdCD().equals(cd.getIdCD())) {
                return idx;
            }
            idx++;
        }
        return -1;
    }

    public void showList() {
        for (CD item : this) {
            item.showInfor();
        }
    }

    public boolean saveToFile() {
        File f = new File("CDStorage.txt");
        try {
            try (PrintWriter writer = new PrintWriter(f)) {
                writer.print("");
            }
            OutputStream outputStream = new FileOutputStream(f);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);

            for (CD item : this) {
                outputStreamWriter.write(item.toString());
                outputStreamWriter.write("\n");
            }
            outputStreamWriter.flush();//lưu xong mới ngừng
            return true;
        } catch (IOException e) {
            System.out.println("Can not Save");
            return false;
        }
    }

    private boolean readFile() {
        this.clear();
        File f = new File("CDStorage.txt");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = reader.readLine();
            while (line != null) {
                //xử lý line
                CD cd = new CD();
                StringTokenizer stLine = new StringTokenizer(line, ",");
                String[] lineParameters = new String[CD.getATTRIBUTE_COUNT()];
                for (int i = 0; i < CD.getATTRIBUTE_COUNT(); i++) {
                    lineParameters[i] = stLine.nextToken().trim();
                }
                if (cd.setAttribute(lineParameters) != 0) {
                    this.add(cd);
                }
                line = reader.readLine();
            }

            return true;
        } catch (IOException e) {
            System.out.println("File Error Exception");
            return false;
        } catch (NumberFormatException e) {
            System.err.println("Wrong number format. Check \"Product.dat\" file again. Exiting...\n");
            System.exit(1);
            return false;
        }
    }

    public void sortByTitle(List<CD> list) {
        Collections.sort(list, (CD c1, CD c2) -> c1.getTitleCD()
                .compareToIgnoreCase(c2.getTitleCD()));
    }

    public void listReadFile(String input) {
        List a = filterName(input);
        if (a == null) {
            System.out.println("Can't find anyone similar to " + input);
            return;
        }
        Collections.sort(a, (CD s1, CD s2) -> (s2.getNameCD().charAt(1) - s1.getNameCD().charAt(1)) * -1);
        for (Object obj : a) {
            CD cd = (CD) obj;
            cd.showInfor();
        }
    }

    public List<CD> filterName(String type) {
        List<CD> list = this.stream()
                .filter(item -> item.getNameCD().toLowerCase().matches(type.toLowerCase()))
                .collect(Collectors.toList());
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }

    public List<CD> filterTitle(String title) {
        List<CD> list = this.stream()
                .filter(item -> item.getTitleCD().toLowerCase().matches(title.toLowerCase()))
                .collect(Collectors.toList());
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }
}
